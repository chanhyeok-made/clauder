---
doc_id: 8
---

# 문서 작성 표준

## 베이스 원칙
@.base-principles/documentation/clear-standards.md

이 프로젝트는 위 베이스 원칙을 따릅니다.

## 프로젝트별 추가 사항
필요시 프로젝트 특화 규칙을 여기에 추가하세요.

## 관련 가이드
- @.claude/guides/documentation/ - 문서 작업 가이드