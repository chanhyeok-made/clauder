---
doc_id: 10
---

# 디렉토리 구조

## 베이스 원칙
@.base-principles/structure/directory-organization.md

이 프로젝트는 위 베이스 원칙을 따릅니다.

## 프로젝트별 추가 사항
필요시 프로젝트 특화 규칙을 여기에 추가하세요.

## 관련 가이드
- @.claude/workflow/04-documentation.md - 문서화 워크플로우