---
doc_id: 758
---

# 워크플로우 체크리스트 템플릿

> 이 템플릿을 복사하여 각 작업 시작 시 TODO에 포함시킵니다.

## 작업: [작업명]

### DONE: 1. 분석 단계
- [ ] @.claude/workflow/01-analysis.md 확인
- [ ] 관련 문서 모두 읽기
- [ ] 현황 파악 완료
- [ ] 세부 TODO 생성

### DONE: 2. 구현 단계  
- [ ] @.claude/workflow/02-implementation.md 확인
- [ ] 코드/문서 작성
- [ ] 테스트/검증 수행
- [ ] TODO 상태 업데이트

### DONE: 3. 회고 단계
- [ ] @.claude/workflow/03-retrospective.md 확인
- [ ] 배운 점 정리
- [ ] 실수/개선점 기록
- [ ] 학습사항 문서화 필요성 판단

### DONE: 4. 문서화 단계
- [ ] @.claude/workflow/04-documentation.md 확인
- [ ] 새 문서 생성 시:
  - [ ] doc_id 추가
  - [ ] **버전 트리 즉시 업데이트**
  - [ ] 참조 관계 설정
- [ ] 기존 문서 수정 시:
  - [ ] 메타데이터 업데이트
  - [ ] 참조 일관성 확인

### DONE: 5. 커밋 단계
- [ ] @.claude/workflow/05-commit.md 확인
- [ ] git status 실행
- [ ] 모든 변경사항 확인
- [ ] 버전 트리 포함 여부 확인
- [ ] 의미있는 커밋 메시지 작성

## ALERT: 놓치기 쉬운 항목
1. **새 문서 → 버전 트리**
2. **학습사항 → learnings/ 디렉토리**
3. **원칙 위반 → 즉시 수정**