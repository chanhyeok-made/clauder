---
doc_id: 1008
created: 2025-08-09
---

# 문서화 컨벤션 (통합본)

> 이 문서는 기존 3곳에 분산된 문서화 원칙을 통합한 것입니다.

## 파일명 규칙

```
일반 문서: lowercase-kebab-case.md
분석 문서: analysis-{topic}-{YYYY-MM-DD}.md
학습 문서: learning-{topic}-{YYYY-MM-DD}.md
템플릿: {name}.template.md
```

## 필수 문서 구조

```markdown
---
doc_id: {number}  # 필수
version: {major.minor.patch}  # 선택
last_updated: {YYYY-MM-DD}  # 선택
---

# 제목

## 목적
한 문장으로 이 문서의 목적 설명

## 핵심 내용
- 구체적 지시
- 실행 가능한 명령
- 검증 가능한 체크리스트
```

## 작성 원칙

### 명료성
- **한 문서 한 개념**: 모듈화 원칙 준수
- **구체적 지시**: 추상적 표현 금지
- **실행 가능**: 복사-붙여넣기로 바로 실행

### 일관성
- **톤**: 전문적이고 간결한 어조
- **형식**: 모든 문서 동일한 구조
- **참조**: @ 프리픽스 사용

### 효과성
- **토큰 최적화**: 중복 내용 제거
- **검증 가능**: 체크리스트 포함
- **버전 관리**: doc_id 필수

## 금지 사항

FORBIDDEN: 과도한 경고 메시지 (!, WARNING: 남용)
FORBIDDEN: 감정적 표현
FORBIDDEN: 모호한 표현
FORBIDDEN: 너무 긴 설명
FORBIDDEN: 중복 내용

## 체크리스트

문서 작성 완료 시:
- [ ] doc_id 포함되었는가?
- [ ] 제목이 명확한가?
- [ ] 한 개념만 다루는가?
- [ ] 실행 가능한 내용인가?
- [ ] 참조가 올바른가?

## 관련 문서
- 전체 원칙: @.base-principles/README.md
- 참조 구조: @.clauder-dev/principles/01-REFERENCE-STRUCTURE.md