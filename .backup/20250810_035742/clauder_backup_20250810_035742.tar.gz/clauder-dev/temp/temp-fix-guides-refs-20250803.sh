#\!/bin/bash

# guides 파일명 변경에 따른 참조 수정 스크립트

echo "=== guides 파일 참조 수정 시작 ==="

# 모든 md 파일에서 대문자 참조를 소문자로 변경
find . -name "*.md" -type f -exec sed -i.bak \
  -e 's/CAPABILITIES\.md/capabilities.md/g' \
  -e 's/TROUBLESHOOTING\.md/troubleshooting.md/g' \
  -e 's/WORKFLOWS\.md/workflows.md/g' \
  {} \;

echo "=== 수정 완료. 백업 파일 삭제 중 ==="
find . -name "*.md.bak" -type f -delete

echo "=== 완료\! ==="
