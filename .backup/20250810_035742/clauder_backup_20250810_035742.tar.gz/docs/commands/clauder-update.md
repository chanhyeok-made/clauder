---
doc_id: 111
---

프로젝트 설정 업데이트

## 고유 기능
```
update project       # 프로젝트 정보
update settings      # 설정
update templates     # 템플릿 동기화
```

## 프로세스
1. 현재 설정 표시
2. 변경사항 입력
3. CLAUDE.md 재생성

@TODO-ALIAS
