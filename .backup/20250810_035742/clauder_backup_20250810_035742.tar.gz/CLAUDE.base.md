---
doc_id: 518
---

- `{{PROJECT_NAME}}`: 프로젝트 이름
- `{{PROJECT_DESCRIPTION}}`: 프로젝트 간단 설명
- `{{TECH_STACK}}`: 사용 기술 목록
- `{{MAIN_PURPOSE}}`: 프로젝트 주요 목적
- `{{QUICK_START_GUIDE}}`: 빠른 시작 가이드
- `{{PROJECT_STRUCTURE}}`: 디렉토리 구조
- `{{WORK_PRINCIPLES}}`: 작업 원칙
- `{{CODING_CONVENTIONS}}`: 코딩 규칙
- `{{TEST_BUILD_COMMANDS}}`: 테스트/빌드 명령어

이 변수들을 실제 프로젝트 정보로 대체하세요.
